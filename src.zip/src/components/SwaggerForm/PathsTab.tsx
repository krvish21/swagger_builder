import React from 'react';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from '@dnd-kit/core';
import {
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Button,
  Checkbox,
  Chip,
  Divider,
  FormControl,
  FormControlLabel,
  FormGroup,
  IconButton,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  Switch,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import DescriptionIcon from '@mui/icons-material/Description';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import PlaylistAddIcon from '@mui/icons-material/PlaylistAdd';
import type { SwaggerPath, SwaggerSchema, PathParameter, PathResponse, RequestBody, SwaggerSecurityScheme } from '../../types/swagger';
import { getMethodColor } from '../../constants/httpMethods';
import { SortableItem } from './SortableItem';
import { MarkdownEditor } from './MarkdownEditor';

interface PathsTabProps {
  paths: SwaggerPath[];
  schemas: SwaggerSchema[];
  securitySchemes: SwaggerSecurityScheme[];
  onAdd: () => void;
  onUpdate: (index: number, field: keyof SwaggerPath, value: unknown) => void;
  onRemove: (index: number) => void;
  onDuplicate: (index: number) => void;
  onReorder: (oldIndex: number, newIndex: number) => void;
  onAddParameter: (pathIndex: number) => void;
  onUpdateParameter: (pathIndex: number, paramIndex: number, field: keyof PathParameter, value: unknown) => void;
  onRemoveParameter: (pathIndex: number, paramIndex: number) => void;
  onAddResponse: (pathIndex: number) => void;
  onUpdateResponse: (pathIndex: number, respIndex: number, field: keyof PathResponse, value: string) => void;
  onRemoveResponse: (pathIndex: number, respIndex: number) => void;
  onAddCommonErrorResponses: (pathIndex: number) => void;
  onAddRequestBody: (pathIndex: number) => void;
  onUpdateRequestBody: (pathIndex: number, field: keyof RequestBody, value: unknown) => void;
  onRemoveRequestBody: (pathIndex: number) => void;
}

export const PathsTab: React.FC<PathsTabProps> = ({
  paths,
  schemas,
  securitySchemes,
  onAdd,
  onUpdate,
  onRemove,
  onDuplicate,
  onReorder,
  onAddParameter,
  onUpdateParameter,
  onRemoveParameter,
  onAddResponse,
  onUpdateResponse,
  onRemoveResponse,
  onAddCommonErrorResponses,
  onAddRequestBody,
  onUpdateRequestBody,
  onRemoveRequestBody,
}) => {
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (over && active.id !== over.id) {
      const oldIndex = paths.findIndex((_, i) => `path-${i}` === active.id);
      const newIndex = paths.findIndex((_, i) => `path-${i}` === over.id);
      onReorder(oldIndex, newIndex);
    }
  };

  return (
    <Stack spacing={3}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h6" sx={{ fontWeight: 600, color: '#374151' }}>
          API Paths
        </Typography>
        <Button variant="contained" startIcon={<AddIcon />} onClick={onAdd} sx={{ bgcolor: '#1976d2' }}>
          Add Path
        </Button>
      </Box>
      {paths.length === 0 ? (
        <Box sx={{ textAlign: 'center', py: 4, color: '#6b7280' }}>
          <DescriptionIcon sx={{ fontSize: 48, opacity: 0.5 }} />
          <Typography>No paths added yet. Click "Add Path" to create one.</Typography>
        </Box>
      ) : (
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
          <SortableContext items={paths.map((_, i) => `path-${i}`)} strategy={verticalListSortingStrategy}>
            <Stack spacing={2} sx={{ pl: 4 }}>
              {paths.map((path, pathIndex) => (
                <SortableItem key={`path-${pathIndex}`} id={`path-${pathIndex}`}>
                  <Accordion 
                    defaultExpanded
                    sx={{
                      borderLeft: `4px solid ${getMethodColor(path.method)}`,
                      '&:before': { display: 'none' }, // Remove default MUI divider
                    }}
                  >
                    <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                        <Chip
                          label={path.method.toUpperCase()}
                          size="small"
                          sx={{ bgcolor: getMethodColor(path.method), color: '#fff', fontWeight: 'bold' }}
                        />
                        <Typography sx={{ fontFamily: 'monospace' }}>{path.path || '/path'}</Typography>
                      </Box>
                    </AccordionSummary>
                    <AccordionDetails>
                      <Stack spacing={3}>
                        {/* Duplicate Action at top */}
                        <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                          <Tooltip title="Duplicate this path">
                            <Button size="small" variant="outlined" startIcon={<ContentCopyIcon />} onClick={() => onDuplicate(pathIndex)}>
                              Duplicate Path
                            </Button>
                          </Tooltip>
                        </Box>

                        <Box sx={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 2 }}>
                          <TextField
                            label="Path"
                            value={path.path}
                            onChange={(e) => onUpdate(pathIndex, 'path', e.target.value)}
                            placeholder="/contract-accounts/{id}/payment-plans"
                            size="small"
                            fullWidth
                          />
                          <FormControl size="small" fullWidth>
                            <InputLabel>Method</InputLabel>
                            <Select value={path.method} label="Method" onChange={(e) => onUpdate(pathIndex, 'method', e.target.value)}>
                              <MenuItem value="get">GET</MenuItem>
                              <MenuItem value="post">POST</MenuItem>
                              <MenuItem value="put">PUT</MenuItem>
                              <MenuItem value="delete">DELETE</MenuItem>
                              <MenuItem value="patch">PATCH</MenuItem>
                            </Select>
                          </FormControl>
                        </Box>

                        <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2 }}>
                          <TextField
                            label="Summary"
                            value={path.summary}
                            onChange={(e) => onUpdate(pathIndex, 'summary', e.target.value)}
                            placeholder="Short summary of the operation"
                            size="small"
                            fullWidth
                          />
                          <TextField
                            label="Operation ID"
                            value={path.operationId}
                            onChange={(e) => onUpdate(pathIndex, 'operationId', e.target.value)}
                            placeholder="getPaymentPlans"
                            size="small"
                            fullWidth
                          />
                        </Box>
                        
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                          <TextField
                            label="Description"
                            value={path.description}
                            onChange={(e) => onUpdate(pathIndex, 'description', e.target.value)}
                            placeholder="Detailed description..."
                            size="small"
                            fullWidth
                            multiline
                            rows={2}
                          />
                          <FormControlLabel
                            control={
                              <Switch
                                checked={path.deprecated || false}
                                onChange={(e) => onUpdate(pathIndex, 'deprecated', e.target.checked)}
                                size="small"
                                color="warning"
                              />
                            }
                            label="Deprecated"
                            sx={{ minWidth: 120 }}
                          />
                        </Box>

                        {/* Security Section */}
                        {securitySchemes.length > 0 && (
                          <>
                            <Divider />
                            <Box>
                              <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1 }}>Security</Typography>
                              <FormGroup row>
                                {securitySchemes.map((scheme) => (
                                  <FormControlLabel
                                    key={scheme.name}
                                    control={
                                      <Checkbox
                                        checked={path.security?.includes(scheme.name) || false}
                                        onChange={(e) => {
                                          const currentSecurity = path.security || [];
                                          const newSecurity = e.target.checked
                                            ? [...currentSecurity, scheme.name]
                                            : currentSecurity.filter((s) => s !== scheme.name);
                                          onUpdate(pathIndex, 'security', newSecurity);
                                        }}
                                        size="small"
                                      />
                                    }
                                    label={`${scheme.name} (${scheme.type})`}
                                  />
                                ))}
                              </FormGroup>
                            </Box>
                          </>
                        )}

                        <Divider />

                        {/* Parameters Section */}
                        <Box>
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                            <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>Parameters</Typography>
                            <Button size="small" startIcon={<AddIcon />} onClick={() => onAddParameter(pathIndex)}>
                              Add Parameter
                            </Button>
                          </Box>
                          <Stack spacing={1}>
                            {path.parameters.map((param, paramIndex) => (
                              <Box
                                key={paramIndex}
                                sx={{ display: 'flex', gap: 1, alignItems: 'center', p: 1.5, bgcolor: '#f9fafb', borderRadius: 1 }}
                              >
                                <TextField
                                  label="Name"
                                  value={param.name}
                                  onChange={(e) => onUpdateParameter(pathIndex, paramIndex, 'name', e.target.value)}
                                  size="small"
                                  sx={{ width: 150 }}
                                />
                                <FormControl size="small" sx={{ width: 100 }}>
                                  <InputLabel>In</InputLabel>
                                  <Select value={param.in} label="In" onChange={(e) => onUpdateParameter(pathIndex, paramIndex, 'in', e.target.value)}>
                                    <MenuItem value="path">path</MenuItem>
                                    <MenuItem value="query">query</MenuItem>
                                    <MenuItem value="header">header</MenuItem>
                                    <MenuItem value="cookie">cookie</MenuItem>
                                  </Select>
                                </FormControl>
                                <TextField
                                  label="Description"
                                  value={param.description}
                                  onChange={(e) => onUpdateParameter(pathIndex, paramIndex, 'description', e.target.value)}
                                  size="small"
                                  sx={{ flex: 1 }}
                                />
                                <FormControlLabel
                                  control={
                                    <Switch
                                      checked={param.required}
                                      onChange={(e) => onUpdateParameter(pathIndex, paramIndex, 'required', e.target.checked)}
                                      size="small"
                                    />
                                  }
                                  label="Required"
                                />
                                <IconButton onClick={() => onRemoveParameter(pathIndex, paramIndex)} color="error" size="small">
                                  <DeleteIcon />
                                </IconButton>
                              </Box>
                            ))}
                          </Stack>
                        </Box>

                        {/* Request Body Section - Not available for GET method */}
                        {path.method !== 'get' && (
                          <>
                            <Divider />
                            <Box>
                              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                                <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>Request Body</Typography>
                                <Button size="small" startIcon={<AddIcon />} onClick={() => onAddRequestBody(pathIndex)}>
                                  Add Request Body
                                </Button>
                              </Box>
                              {path.requestBody && (
                                <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', p: 1.5, bgcolor: '#f9fafb', borderRadius: 1 }}>
                                  <TextField
                                    label="Description"
                                    value={path.requestBody.description}
                                    onChange={(e) => onUpdateRequestBody(pathIndex, 'description', e.target.value)}
                                    size="small"
                                    sx={{ flex: 1 }}
                                  />
                                  <FormControl size="small" sx={{ width: 150 }}>
                                    <InputLabel>Schema Ref</InputLabel>
                                    <Select
                                      value={path.requestBody.schemaRef}
                                      label="Schema Ref"
                                      onChange={(e) => onUpdateRequestBody(pathIndex, 'schemaRef', e.target.value)}
                                    >
                                      <MenuItem value="">None</MenuItem>
                                      {schemas.map((schema) => (
                                        <MenuItem key={schema.name} value={schema.name}>{schema.name}</MenuItem>
                                      ))}
                                    </Select>
                                  </FormControl>
                                  <IconButton onClick={() => onRemoveRequestBody(pathIndex)} color="error" size="small">
                                    <DeleteIcon />
                                  </IconButton>
                                </Box>
                              )}
                            </Box>
                          </>
                        )}

                        <Divider />

                        {/* Responses Section */}
                        <Box>
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                            <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>Responses</Typography>
                            <Box sx={{ display: 'flex', gap: 1 }}>
                              <Tooltip title="Add common error responses (400, 401, 403, 404, 500)">
                                <Button size="small" variant="outlined" startIcon={<PlaylistAddIcon />} onClick={() => onAddCommonErrorResponses(pathIndex)}>
                                  Error Responses
                                </Button>
                              </Tooltip>
                              <Button size="small" startIcon={<AddIcon />} onClick={() => onAddResponse(pathIndex)}>
                                Add Response
                              </Button>
                            </Box>
                          </Box>
                          <Stack spacing={2}>
                            {path.responses.map((resp, respIndex) => (
                              <Box
                                key={respIndex}
                                sx={{ p: 2, bgcolor: '#f9fafb', borderRadius: 1, border: '1px solid #e5e7eb' }}
                              >
                                <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', mb: 2 }}>
                                  <FormControl size="small" sx={{ width: 100 }}>
                                    <InputLabel>Status</InputLabel>
                                    <Select
                                      value={resp.statusCode}
                                      label="Status"
                                      onChange={(e) => onUpdateResponse(pathIndex, respIndex, 'statusCode', e.target.value)}
                                    >
                                      <MenuItem value="200">200</MenuItem>
                                      <MenuItem value="201">201</MenuItem>
                                      <MenuItem value="204">204</MenuItem>
                                      <MenuItem value="400">400</MenuItem>
                                      <MenuItem value="401">401</MenuItem>
                                      <MenuItem value="403">403</MenuItem>
                                      <MenuItem value="404">404</MenuItem>
                                      <MenuItem value="500">500</MenuItem>
                                    </Select>
                                  </FormControl>
                                  <FormControl size="small" sx={{ width: 150 }}>
                                    <InputLabel>Schema Ref</InputLabel>
                                    <Select
                                      value={resp.schemaRef}
                                      label="Schema Ref"
                                      onChange={(e) => onUpdateResponse(pathIndex, respIndex, 'schemaRef', e.target.value)}
                                    >
                                      <MenuItem value="">None</MenuItem>
                                      {schemas.map((schema) => (
                                        <MenuItem key={schema.name} value={schema.name}>{schema.name}</MenuItem>
                                      ))}
                                    </Select>
                                  </FormControl>
                                  <Box sx={{ flex: 1 }} />
                                  <IconButton onClick={() => onRemoveResponse(pathIndex, respIndex)} color="error" size="small">
                                    <DeleteIcon />
                                  </IconButton>
                                </Box>
                                <MarkdownEditor
                                  value={resp.description}
                                  onChange={(value) => onUpdateResponse(pathIndex, respIndex, 'description', value)}
                                  label="Description"
                                  placeholder="Response description... (Supports Markdown)"
                                  rows={3}
                                />
                              </Box>
                            ))}
                          </Stack>
                        </Box>

                        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
                          <Button variant="outlined" color="error" startIcon={<DeleteIcon />} onClick={() => onRemove(pathIndex)}>
                            Delete Path
                          </Button>
                        </Box>
                      </Stack>
                    </AccordionDetails>
                  </Accordion>
                </SortableItem>
              ))}
            </Stack>
          </SortableContext>
        </DndContext>
      )}
    </Stack>
  );
};