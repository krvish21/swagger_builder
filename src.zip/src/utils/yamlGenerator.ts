import type { SwaggerDocument } from '../types/swagger';

/**
 * Formats a description for YAML output.
 * Uses literal block scalar (|) for multi-line content to preserve formatting.
 */
const formatDescription = (description: string, indent: number): string => {
  if (!description) {
    return `''`;
  }
  
  // Check if description contains newlines (multi-line content)
  if (description.includes('\n')) {
    const indentStr = ' '.repeat(indent);
    const lines = description.split('\n');
    // Use literal block scalar (|) to preserve newlines and formatting
    return `|\n${lines.map(line => `${indentStr}${line}`).join('\n')}`;
  }
  
  // Single line - escape single quotes and wrap in quotes
  return `'${description.replace(/'/g, "''")}'`;
};

export const buildYamlDocument = (doc: SwaggerDocument): string => {
  let yaml = `openapi: ${doc.openapi}\n`;
  yaml += `info:\n`;
  yaml += `  title: ${doc.info.title}\n`;
  yaml += `  description: ${formatDescription(doc.info.description, 4)}\n`;
  yaml += `  version: "${doc.info.version}"\n`;
  
  // Terms of Service
  if (doc.info.termsOfService) {
    yaml += `  termsOfService: ${doc.info.termsOfService}\n`;
  }
  
  // Contact
  if (doc.info.contact && (doc.info.contact.name || doc.info.contact.email || doc.info.contact.url)) {
    yaml += `  contact:\n`;
    if (doc.info.contact.name) {
      yaml += `    name: ${doc.info.contact.name}\n`;
    }
    if (doc.info.contact.email) {
      yaml += `    email: ${doc.info.contact.email}\n`;
    }
    if (doc.info.contact.url) {
      yaml += `    url: ${doc.info.contact.url}\n`;
    }
  }
  
  // License
  if (doc.info.license && doc.info.license.name) {
    yaml += `  license:\n`;
    yaml += `    name: ${doc.info.license.name}\n`;
    if (doc.info.license.url) {
      yaml += `    url: ${doc.info.license.url}\n`;
    }
  }

  // Servers
  if (doc.servers.length > 0) {
    yaml += `servers:\n`;
    doc.servers.forEach((server) => {
      yaml += `  - url: ${server.url}\n`;
      if (server.description) {
        yaml += `    description: ${formatDescription(server.description, 6)}\n`;
      }
    });
  }

  if (doc.tags.length > 0) {
    yaml += `tags:\n`;
    doc.tags.forEach((tag) => {
      yaml += `  - name: ${tag.name}\n`;
      yaml += `    description: ${formatDescription(tag.description, 6)}\n`;
    });
  }

  if (doc.paths.length > 0) {
    yaml += `paths:\n`;
    doc.paths.forEach((path) => {
      yaml += `  '${path.path}':\n`;
      yaml += `    ${path.method}:\n`;
      if (path.tags.length > 0) {
        yaml += `      tags:\n`;
        path.tags.forEach((tag) => {
          yaml += `        - ${tag}\n`;
        });
      }
      yaml += `      summary: ${path.summary}\n`;
      yaml += `      operationId: ${path.operationId}\n`;
      yaml += `      description: ${formatDescription(path.description, 8)}\n`;
      
      // Deprecated flag
      if (path.deprecated) {
        yaml += `      deprecated: true\n`;
      }

      if (path.parameters.length > 0) {
        yaml += `      parameters:\n`;
        path.parameters.forEach((param) => {
          yaml += `        - name: ${param.name}\n`;
          yaml += `          in: ${param.in}\n`;
          yaml += `          description: ${formatDescription(param.description, 12)}\n`;
          yaml += `          required: ${param.required}\n`;
          if (param.deprecated) {
            yaml += `          deprecated: true\n`;
          }
          yaml += `          schema:\n`;
          yaml += `            type: ${param.type}\n`;
          if (param.format) {
            yaml += `            format: ${param.format}\n`;
          }
          if (param.enum) {
            const enumArray = param.enum.split(',').map((v) => v.trim()).filter((v) => v !== '');
            if (enumArray.length > 0) {
              yaml += `            enum:\n`;
              enumArray.forEach((enumValue) => {
                yaml += `              - ${enumValue}\n`;
              });
            }
          }
          if (param.default) {
            yaml += `            default: ${param.default}\n`;
          }
          if (param.example) {
            yaml += `          example: ${param.example}\n`;
          }
        });
      }

      // Request Body
      if (path.requestBody) {
        yaml += `      requestBody:\n`;
        if (path.requestBody.description) {
          yaml += `        description: ${formatDescription(path.requestBody.description, 10)}\n`;
        }
        yaml += `        required: ${path.requestBody.required}\n`;
        yaml += `        content:\n`;
        yaml += `          ${path.requestBody.contentType || 'application/json'}:\n`;
        yaml += `            schema:\n`;
        if (path.requestBody.schemaRef) {
          yaml += `              $ref: '#/components/schemas/${path.requestBody.schemaRef}'\n`;
        } else {
          yaml += `              type: object\n`;
        }
      }

      if (path.responses.length > 0) {
        yaml += `      responses:\n`;
        path.responses.forEach((resp) => {
          yaml += `        '${resp.statusCode}':\n`;
          yaml += `          description: ${formatDescription(resp.description, 12)}\n`;
          yaml += `          content:\n`;
          yaml += `            application/vnd.api+json:\n`;
          yaml += `              schema:\n`;
          if (resp.schemaRef) {
            yaml += `                $ref: '#/components/schemas/${resp.schemaRef}'\n`;
          } else {
            yaml += `                type: object\n`;
          }
        });
      }
    });
  }

  // Components section (schemas + securitySchemes)
  const hasSchemas = doc.schemas.length > 0;
  const hasSecuritySchemes = doc.securitySchemes.length > 0;

  if (hasSchemas || hasSecuritySchemes) {
    yaml += `components:\n`;

    // Security Schemes
    if (hasSecuritySchemes) {
      yaml += `  securitySchemes:\n`;
      doc.securitySchemes.forEach((scheme) => {
        yaml += `    ${scheme.name}:\n`;
        yaml += `      type: ${scheme.type}\n`;
        if (scheme.type === 'http') {
          yaml += `      scheme: ${scheme.scheme || 'bearer'}\n`;
          if (scheme.scheme === 'bearer' && scheme.bearerFormat) {
            yaml += `      bearerFormat: ${scheme.bearerFormat}\n`;
          }
        } else if (scheme.type === 'apiKey') {
          yaml += `      in: ${scheme.in || 'header'}\n`;
          yaml += `      name: ${scheme.apiKeyName || 'X-API-Key'}\n`;
        }
      });
    }

    // Schemas
    if (hasSchemas) {
      yaml += `  schemas:\n`;
      doc.schemas.forEach((schema) => {
        yaml += `    ${schema.name}:\n`;
        yaml += `      type: ${schema.type}\n`;
        if (schema.properties.length > 0) {
          yaml += `      properties:\n`;
          schema.properties.forEach((prop) => {
            yaml += `        ${prop.name}:\n`;

            // Handle object type with $ref
            if (prop.type === 'object' && prop.$ref) {
              yaml += `          $ref: '#/components/schemas/${prop.$ref}'\n`;
            }
            // Handle array type
            else if (prop.type === 'array') {
              yaml += `          type: array\n`;
              yaml += `          items:\n`;
              if (prop.items?.$ref) {
                yaml += `            $ref: '#/components/schemas/${prop.items.$ref}'\n`;
              } else {
                yaml += `            type: ${prop.items?.type || 'string'}\n`;
              }
              if (prop.description) {
                yaml += `          description: ${formatDescription(prop.description, 10)}\n`;
              }
            }
            // Handle primitive types
            else {
              yaml += `          type: ${prop.type}\n`;
              if (prop.format) {
                yaml += `          format: ${prop.format}\n`;
              }
              if (prop.nullable) {
                yaml += `          nullable: true\n`;
              }
              if (prop.deprecated) {
                yaml += `          deprecated: true\n`;
              }
              if (prop.readOnly) {
                yaml += `          readOnly: true\n`;
              }
              if (prop.writeOnly) {
                yaml += `          writeOnly: true\n`;
              }
              if (prop.default) {
                yaml += `          default: ${prop.default}\n`;
              }
              if (prop.pattern) {
                yaml += `          pattern: '${prop.pattern}'\n`;
              }
              // String constraints
              if (prop.type === 'string') {
                if (prop.minLength !== undefined && prop.minLength !== null) {
                  yaml += `          minLength: ${prop.minLength}\n`;
                }
                if (prop.maxLength !== undefined && prop.maxLength !== null) {
                  yaml += `          maxLength: ${prop.maxLength}\n`;
                }
              }
              // Number constraints
              if (prop.type === 'number' || prop.type === 'integer') {
                if (prop.minimum !== undefined && prop.minimum !== null) {
                  yaml += `          minimum: ${prop.minimum}\n`;
                }
                if (prop.maximum !== undefined && prop.maximum !== null) {
                  yaml += `          maximum: ${prop.maximum}\n`;
                }
              }
              // Parse enumValues string into array for YAML output
              const enumArray = prop.enumValues
                ? prop.enumValues.split(',').map((v) => v.trim()).filter((v) => v !== '')
                : [];
              if (enumArray.length > 0) {
                yaml += `          enum:\n`;
                enumArray.forEach((enumValue) => {
                  yaml += `            - ${enumValue}\n`;
                });
              }
              if (prop.description) {
                yaml += `          description: ${formatDescription(prop.description, 10)}\n`;
              }
              if (prop.example) {
                yaml += `          example: ${prop.example}\n`;
              }
            }
          });
        }
      });
    }
  }

  // Global security (if security schemes defined)
  if (hasSecuritySchemes) {
    yaml += `security:\n`;
    doc.securitySchemes.forEach((scheme) => {
      yaml += `  - ${scheme.name}: []\n`;
    });
  }

  return yaml;
};