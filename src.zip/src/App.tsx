import './index.css';
import { SwaggerForm } from './components/SwaggerForm';

function App() {
  return <SwaggerForm />;
}

export default App;
